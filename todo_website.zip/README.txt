
Todo Website (static)
Features:
- 자동으로 오늘 날짜 표시
- 오늘 일정 기준 달성률 계산 (기본) & 진행 바
- 체크는 LocalStorage에 저장되어 새로고침/종료 후에도 유지
- 다크모드, 목표 개수 설정, 100% 달성 시 폭죽 애니메이션
- print.html: A4 인쇄 / 구글 시트 붙여넣기용 테이블
Source tasks extracted from uploaded PDF (see conversation). Citation: fileciteturn0file0
How to use:
- unzip and host on GitHub Pages (push contents to gh-pages or main branch docs/)
